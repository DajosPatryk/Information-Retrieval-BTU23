//The below import statements import necessary classes from the Java API for file handling, collections, and input/output operations.
import java.io.*;
import java.nio.file.*;
import java.util.*;
//'App' is main class of the program. It contains the main method, which serves as the entry point for the program.
public class App {
        //The main method initializes variables for the input directory, output directory, and the path to a stopwords file.
        public static void main(String[] args) {
        String inputDirectory = "C:\\Users\\LENOVO\\IdeaProjects\\Vidya_New\\src\\collection_original"; // Path to the directory containing the original files
        String outputDirectory = "C:\\Users\\LENOVO\\IdeaProjects\\Vidya_New\\src\\collection_no_stopwords"; // Path to the directory where processed files will be stored
        String stopWordsFilePath = "F:\\BTU\\Summer Semester - Sem 2 - AI\\Information Retrieval\\englishST.txt";

        //The loadStopWords method is called to load the stopwords from the file.
        Set<String> stopWords = loadStopWords(stopWordsFilePath);

        // this code checks if the input directory exists and contains files
        File inputDir = new File(inputDirectory);
        if (!inputDir.exists() || !inputDir.isDirectory() || inputDir.listFiles().length == 0) {
            System.out.println("No files found in the input directory.");
            return;
        }
        // processFiles method is called to process the files in the input directory.
        processFiles(inputDirectory, outputDirectory, stopWords);
        // Below line prints a success message when the task is finished.
        System.out.println("Task Finished with Success");
    }
    //The methos 'loadStopWords'takes a file path as input and returns a Set of stopwords loaded from the file.
    public static Set<String> loadStopWords(String filePath) {
        Set<String> stopWords = new HashSet<>();
        //The file is read using a BufferedReader and adds each line (trimmed) to the stopWords set.
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stopWords.add(line.trim());
            }
        } catch (IOException e) {
            System.out.println("Error loading stop words: " + e.getMessage());
        }

        return stopWords;
    }
    //The method processFiles takes the input directory, output directory, and a set of stopwords as inputs.
    public static void processFiles(String inputDirectory, String outputDirectory, Set<String> stopWords) {
        File[] files = getFilesFromDirectory(inputDirectory);// It retrieves the files from the input directory.

        for (File file : files) {
            if (file.isFile()) {
                String inputFilePath = file.getAbsolutePath();
                String outputFilePath = outputDirectory + file.getName();
            //The method 'processDocument' is called  for each file to process it.
                processDocument(inputFilePath, outputFilePath, stopWords);
            }
        }
    }
        //The method 'processDocument' takes the input file path, output file path, and a set of stopwords as inputs.
    public static void processDocument(String inputFilePath, String outputFilePath, Set<String> stopWords) {
        try {
            FileController fc = new FileController(inputFilePath); //It creates a FileController object for the input file.
            List<List<String>> collection = divideDocument(fc); //The method 'divideDocument' is called to divide the document into separate parts.

            List<String> processedDocument = new ArrayList<>();
            for (List<String> document : collection) {
                List<String> processedLines = removeStopWords(document, stopWords);//Each part of the document is processed by removing stopwords using the removeStopWords method.
                processedDocument.addAll(processedLines);
            }

            fc.createTextFile(outputFilePath, processedDocument); //A text file with the processed document by using File controller object.
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    //The method 'getFilesFromDirectory' takes a directory path as input and returns an array of File objects representing the files in the directory.
    public static File[] getFilesFromDirectory(String directoryPath) {
        File directory = new File(directoryPath);
        return directory.listFiles();
    }
    // The method divideDocument takes a FileController object as input.
    private static List<List<String>> divideDocument(FileController fc) throws Exception {

        List<List<String>> collection = new ArrayList<>();
        List<String> document = new ArrayList<>();

        String line;
        while ((line = fc.bufferedReader.readLine()) != null) { //Here the document is read line by line  from the bufferedReader and it is divided into separate parts based on empty lines.
            if (line.trim().isEmpty()) {
                if (!document.isEmpty()) {
                    collection.add(document);
                    document = new ArrayList<>();
                }
            } else {
                document.add(line);
            }
        }

        if (!document.isEmpty()) {
            collection.add(document);
        }

        return collection; //A list of lists is returned, where each inner list represents a separate document.
    }
    // The method removeStopWords takes a list of strings (document) and a set of stopwords as inputs.
    private static List<String> removeStopWords(List<String> document, Set<String> stopWords) {
        List<String> processedDocument = new ArrayList<>();

        for (String line : document) {
            // Remove punctuation and line breaks while preserving the special meaning of the apostrophe
            String cleanedLine = line.replaceAll("[^\\w\\s']+", "").replaceAll("'(?!\\w)|(?<!\\w)'", "");
            String[] words = cleanedLine.split("\\s+");
            StringBuilder processedLine = new StringBuilder();

            // Stopwords from each line of the document are eliminated in a case-insensitive manner
            for (String word : words) {
                if (!stopWords.contains(word.toLowerCase())) {
                    processedLine.append(word).append(" ");
                }
            }

            processedDocument.add(processedLine.toString().trim());
        }

        return processedDocument;
    }

}

class FileController {
    private File file;
    public BufferedReader bufferedReader;// It takes a file path as input and initializes a BufferedReader to read from the file.

    public FileController(String filePath) throws Exception {
        this.file = new File(filePath);
        try {
            this.bufferedReader = new BufferedReader(new FileReader(file));
        } catch (Exception e) {
            throw new Exception(e);
        }
    }
// It provides a method createTextFile to create a text file with the given filename and write the provided lines into it.
    public void createTextFile(String filename, List<String> lines) throws Exception {
        Files.createDirectories(Paths.get(filename.split("/")[0] + "/" + filename.split("/")[1]));
        File file = new File(filename);
        file.createNewFile();
        FileWriter writer = new FileWriter(filename);
        try {
            for (String line : lines) {
                writer.write(line + "\n");
            }
            writer.close();
        } catch (Exception e) {
            throw new Exception(e);
        }
    }
}
